#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <iterator>

#include <vector>

#include "json.hpp"

template <class Container>
void split(const std::string& str, Container& cont, char delim = ' ')
{
    std::stringstream ss(str);
    std::string token;
    while (std::getline(ss, token, delim)) {
        cont.push_back(token);
    }
}

std::string getFileName(char * path) {
    std::vector<std::string> words;
    split<std::vector<std::string>>(path, words, '\\');
    std::string last = words.back();
    words.clear();
    split<std::vector<std::string>>(last, words, '.');
    return words.front();
}

std::vector<int> barracks_indices;

void processLevelElements(std::ofstream &file, nlohmann::json &json) {
    for (int i = 0; i < json["objects"].size(); i++) {
        std::vector<std::string> name;
        split(json["objects"][i]["name"], name, '_');
        int xloc = (json["objects"][i]["x"].get<float>() + json["objects"][i]["width"].get<float>() / 2.0f ) / 6.0f;
        int yloc = (json["objects"][i]["y"].get<float>() + json["objects"][i]["height"].get<float>() / 2.0f ) / 6.0f;

        std::string leading = "\tSpawnPoint({";
        leading += std::to_string(xloc);
        leading += ", ";
        leading += std::to_string(yloc);
        leading += "}, ";

        if (name[0] == "hackingkit") {
            file << leading << "Pickups::spawnHackingKit),\n";
        } else if (name[0] == "shop") {
            int x1 = xloc + std::stoi(name[1]);
            int y1 = yloc + std::stoi(name[2]);
            int x2 = xloc + std::stoi(name[3]);
            int y2 = yloc + std::stoi(name[4]);
            int x3 = xloc + std::stoi(name[5]);
            int y3 = yloc + std::stoi(name[6]);
            file << leading << "spawnShop<" << x1 << "," << y1 << "," << x2 << "," << y2 << "," << x3 << "," << y3 << ">),\n";
        } else if (name[0] == "barracks") {
            int x = xloc + std::stoi(name[1]);
            int y = yloc + std::stoi(name[2]);
            int w = std::stoi(name[3]);
            int h = std::stoi(name[4]);
            file << leading << "spawnBarracks<" << x << "," << y << "," << w << "," << h << ">),\n";
            barracks_indices.push_back(x + y * 255);
        } else if (name[0] == "door") {
            int x = xloc + std::stoi(name[2]);
            int y = yloc + std::stoi(name[3]);
            int w = std::stoi(name[4]);
            int h = std::stoi(name[5]);
            if (name[1] == "a") {
                file << leading << "spawnDoorA<" << x << "," << y << "," << w << "," << h << ">),\n";
            } else if (name[1] == "b") {
                file << leading << "spawnDoorB<" << x << "," << y << "," << w << "," << h << ">),\n";
            } else if (name[1] == "c") {
                file << leading << "spawnDoorC<" << x << "," << y << "," << w << "," << h << ">),\n";
            } else if (name[1] == "none") {
                file << leading << "spawnDoorNone<" << x << "," << y << "," << w << "," << h << ">),\n";
            }
        } else if (name[0] == "keycard") {
            if (name[1] == "a") {
                file << leading << "Pickups::spawnKeycardA),\n";
            } else if (name[1] == "b") {
                file << leading << "Pickups::spawnKeycardB),\n";
            } else if (name[1] == "c") {
                file << leading << "Pickups::spawnKeycardC),\n";
            }
        } else if (name[0] == "enemy") {
            if (name[1] == "mech") {
                file << leading << "Enemy::spawnMech),\n";
            } else if (name[1] == "turret") {
                file << leading << "Enemy::spawnTurret),\n";
            } else if (name[1] == "tank") {
                file << leading << "Enemy::spawnTank),\n";
            } else if (name[1] == "mine") {
                file << leading << "Enemy::spawnMine),\n";
            } else if (name[1] == "bomber") {
                file << leading << "Enemy::spawnBomber),\n";
            } else if (name[1] == "lasers") {
                int x = json["objects"][i]["x"].get<float>() / 6.0f;
                int y = json["objects"][i]["y"].get<float>() / 6.0f;
                int w = json["objects"][i]["width"].get<float>() / 6.0f;
                w++;
                int h = json["objects"][i]["height"].get<float>() / 6.0f;
                h++;
                if (name[2] == "ns") {
                    file << leading << "spawnVerticalLasers< " << y << ", " << h <<">),\n";
                } else {
                    file << leading << "spawnHorizontalLasers< " << x << ", " << w <<">),\n";
                }
            } else if (name[1] == "heli") {
                file << leading << "Enemy::spawnHelicopter),\n";
            }
        }
    }
}

void processWorldData(std::ofstream &file, nlohmann::json &json) {
    file << "const uint8_t " << json["name"].get<std::string>() << "[] = {";
    file << json["width"].get<int>() << ", " << json["height"].get<int>() << ", ";
    for(int j = 0; j < json["data"].size(); j++) {
        file << json["data"][j].get<int>()-1 << ", ";
    }
    file << "};\n\n";
}

void processMutableData(std::ofstream &file, nlohmann::json &mutables, nlohmann::json &world) {
    file << "const uint8_t can_tile_mutate[] = {";
    std::vector<int> defaults;
    std::vector<int> indices;
    std::string val;
    for(int j = 0; j < mutables.size(); j++) {
        bool can_mutate = mutables[j].get<int>() > 0;
        if (can_mutate) {
            defaults.push_back(world[j].get<int>() - 1);
            indices.push_back(j);
            val = "1" + val;
        } else {
            val = "0" + val;
        }
        if ((j % 8) == 7) {
            file << "0b" << val << ", ";
            val = "";
        }
    }

    file << "};\n\nconst uint16_t mutable_indices[] = { ";
    for(int t : indices) {
        file << t << ", ";
    }

    file << "};\n\nstatic uint8_t current_tiles[] = { ";
    for(int t : defaults) {
        file << t << ", ";
    }
    file << "};\n\nconst uint16_t barracks_indices[] = { ";
    for(int t : barracks_indices) {
        file << t << ", ";
    }
    file << "};\n\nstatic uint8_t barracks_data[] = { ";
    for(int t : barracks_indices) {
        file << "0, ";
    }
    file << "};\n\n";
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        std::cout << "ERROR: Requires input file argument.\n";
        return 1;
    }

    std::string fname = getFileName(argv[1]);
    std::ofstream file(fname + ".h");

    file << "#pragma once\n\n#include <cstdint>\n\n";

    std::ofstream elements("spawnpoints.h");
    elements << "#pragma once\n\n#include \"core/utilities/vec.h\"\n#include \"game/entities/enemy.h\"\n#include \"game/entities/barracks.h\"\n#include \"game/entities/pickups.h\"\n#include \"game/entities/pois.h\"\n#include \"game/maps/spawnpoint.h\"\n\n";
    elements << "const SpawnPoint points[] = {\n";

    nlohmann::json json;
    std::ifstream input(argv[1]);
    input >> json;

    bool has_mutable = false;
    nlohmann::json world_layer, mutable_layer;
    for (int i = 0; i < json["layers"].size(); i++) {
        if (json["layers"][i]["name"] == "world") {
            processWorldData(file, json["layers"][i]);
            world_layer = json["layers"][i]["data"];
        } else if (json["layers"][i]["name"] == "mutable") {
            mutable_layer = json["layers"][i]["data"];
            has_mutable = true;
        } else if (json["layers"][i]["name"] == "level_elements") {
            processLevelElements(elements, json["layers"][i]);
        } else if (!json["layers"][i]["data"].is_null()) {
            processWorldData(file, json["layers"][i]);
        }
    }

    elements << "};\nconst int point_count = sizeof(points)/sizeof(SpawnPoint);\n";

    if (has_mutable) {
        std::ofstream muts("worldmutables.h");
        muts <<  "#pragma once\n\n#include <cstdint>\n\n";
        processMutableData(muts, mutable_layer, world_layer);
    }

    return 0;
}
