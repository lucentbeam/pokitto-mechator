#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

struct Color {
    uint16_t r, g, b;

    Color(std::string hex) {
        r = std::stoi(hex.substr(0,2), 0, 16);
        g = std::stoi(hex.substr(2,2), 0, 16);
        b = std::stoi(hex.substr(4,2), 0, 16);
    }
    Color() = default;
    Color(int ir, int ig, int ib) : r(ir), g(ig), b(ib) {}

    uint16_t to565() const {
        return (r >> 3) << 11 | (g >> 2) << 5 | (b >> 3);
    }

    bool operator==(const Color &other) {
        return r == other.r && g == other.g && b == other.b;
    }

    static Color mix(Color c1, Color c2, float fraction) {
        return Color(float(c1.r) * (1.0f - fraction) + float(c2.r) * fraction, float(c1.g) * (1.0f - fraction) + float(c2.g) * fraction, float(c1.b) * (1.0f - fraction) + float(c2.b) * fraction);
    }
};

std::vector<Color> parse_palette(std::string filename) {
    std::vector<Color> output;
    std::ifstream file(filename);

    if (!file) {
        std::cout << "ERROR: Could not open file " << filename << std::endl;
        return output;
    }

    for (std::string line; std::getline(file, line);) {
        output.push_back(Color(line));
    }
    return output;
}

std::vector<Color> remap(std::vector<Color> colors, int * map) {
    std::vector<Color> output;
    for(int i = 0; i < colors.size(); ++i) {
        output.push_back(colors[map[i]]);
    }
    return output;
}

int shade_steps[] = {
    0, 0, 1, 2, 3,
    4, 2, 6, 7, 8,
    9,50,11,12,13,
    11,15,16,17,18,
    50,20,21,22,23,
    35,25,26,27,28,
    35,30,31,32,33,
    1,35,36,37,38,
    45,40,41,42,43,
    1,45,46,47,48,
    1,50,51,52,53,
    50,55,56,57,50,
    59,60,61,62,63
};

int lighten_steps[] = {
    1, 2, 3, 4, 5,
   39, 7, 8, 9,10,
   10,12,13,14,14,
   16,17,18,19,19,
   21,22,23,24,24,
   26,27,28,29,29,
   31,32,33,34,34,
   36,37,38,39,39,
   41,42,43,44,44,
   46,47,48,49,49,
   51,52,53,54,54,
   56,57,58,58,60,
   61,62,63,64,64
};

typedef std::vector<Color> palette;
#include <string>

void dumpPalette(std::ofstream &file, std::string asname, palette p1, palette p2) {
    file << "const uint16_t " << asname << "_palette[] = {\n\t";
    for(Color c : p1) {
        file << c.to565() << ", ";
    }
    for(Color c : p2) {
        file << c.to565() << ", ";
    }
    file << "\n};\n\n";
}

palette mixPalettes(palette p1, palette p2, float fraction) {
    palette output;
    for(int i = 0; i < p1.size(); ++i) {
        output.push_back(Color::mix(p1[i], p2[i], fraction));
    }
    return output;
}

int main()
{
    palette default_palette = parse_palette("../palette-parser/palette.hex");
    palette light_palette = remap(default_palette, lighten_steps);
    palette light2_palette = remap(light_palette, lighten_steps);
    palette dark1_palette = remap(default_palette, shade_steps);
    palette dark2_palette = remap(dark1_palette, shade_steps);
    palette dark3_palette = remap(dark2_palette, shade_steps);

    std::ofstream file("../../core/palettes.h");
    file << "#ifndef _PALETTES\n#define _PALETTES\n\n#include <cstdint>\n\n";

    dumpPalette(file, "light2", light2_palette, default_palette);
    dumpPalette(file, "light1", light_palette, default_palette);
    dumpPalette(file, "default", default_palette, default_palette);
    dumpPalette(file, "shade1", dark1_palette, default_palette);
    dumpPalette(file, "shade2", dark2_palette, default_palette);
    dumpPalette(file, "shade3", dark3_palette, default_palette);

    file << "const uint16_t * const palette_list[] = { light2_palette, light1_palette, default_palette, shade1_palette, shade2_palette, shade3_palette };\n\n";

    file << "#endif\n";
    return 0;
}
